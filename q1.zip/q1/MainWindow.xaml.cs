﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace q1
{
    public partial class MainWindow : Window
    {
        private string connectionString = "Data Source=DESKTOP-GSJ1HJB\\SQLEXPRESS;Initial Catalog=StudentProgressDB;Integrated Security=True;Trust Server Certificate=True";

        public MainWindow()
        {
            InitializeComponent();
            LoadStudents();
            LoadComboBoxData();
        }

        private void LoadStudents()
        {
           
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Students";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                StudentsDataGrid.ItemsSource = dataTable.DefaultView;
            }

            
        }

        private void LoadComboBoxData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                
                SqlCommand gradeCommand = new SqlCommand("SELECT DISTINCT Grade FROM Students", connection);
                SqlDataReader gradeReader = gradeCommand.ExecuteReader();
                while (gradeReader.Read())
                {
                    GradeComboBox.Items.Add(gradeReader["Grade"].ToString());
                }
                gradeReader.Close();

               
                SqlCommand subjectCommand = new SqlCommand("SELECT DISTINCT Subject FROM Students", connection);
                SqlDataReader subjectReader = subjectCommand.ExecuteReader();
                while (subjectReader.Read())
                {
                    SubjectComboBox.Items.Add(subjectReader["Subject"].ToString());
                }
                subjectReader.Close();
            }
        }

        private void GradeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterStudents();

        }

        private void SubjectComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterStudents();
        }

        private void FilterStudents()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM Students WHERE (Grade = @Grade OR @Grade IS NULL) AND (Subject = @Subject OR @Subject IS NULL)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Grade", GradeComboBox.SelectedItem ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@Subject", SubjectComboBox.SelectedItem ?? (object)DBNull.Value);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    StudentsDataGrid.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error {ex.Message}");
            }
        }

        private void AddStudent_Click(object sender, RoutedEventArgs e)
        {
            student addStudentWindow = new student(connectionString);
            addStudentWindow.ShowDialog();
            LoadStudents();
            
        }
        
        private void delete_student(object sender, RoutedEventArgs e)
        {
            delete d = new delete(connectionString);
            d.ShowDialog();
            LoadStudents();
           
        }

        private void update_student(object sender, RoutedEventArgs e)
        {
            update u = new update(connectionString);    
            u.ShowDialog();
            LoadStudents();
            
        }
    }
}
