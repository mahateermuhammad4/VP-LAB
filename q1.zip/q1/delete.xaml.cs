﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;

namespace q1
{
    /// <summary>
    /// Interaction logic for delete.xaml
    /// </summary>
    public partial class delete : Window
    {
        private string connectionstring;
        public delete(string con)
        {
            InitializeComponent();
            connectionstring = con; 
        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
           if(NameTextBox.Text.IsNullOrEmpty())
            {
                MessageBox.Show("Please enter a valid integer val");
                return;
            }
            int id = int.Parse(NameTextBox.Text);
            
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    connection.Open();
                    string Query = "Delete FROM Students WHERE StudentID=@StudentID";
                    using (SqlCommand command = new SqlCommand(Query, connection))
                    {
                        command.Parameters.AddWithValue("@StudentID", id);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Student record deleted successfully ");
                    }

                }
            }
            catch (Exception ex) { 
                MessageBox.Show(ex.Message);
            }

        }
    }
}
