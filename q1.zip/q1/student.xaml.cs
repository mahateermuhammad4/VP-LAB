﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace q1
{
    
    public partial class student : Window
    {
        private string connectionString;

        public student(string connectionString)
        {
            InitializeComponent();
            this.connectionString = connectionString;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Students (Name, Grade, Subject, Marks, AttendancePercentage) VALUES (@Name, @Grade, @Subject, @Marks, @Attendance)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", NameTextBox.Text);
                command.Parameters.AddWithValue("@Grade", GradeTextBox.Text);
                command.Parameters.AddWithValue("@Subject", SubjectTextBox.Text);
                command.Parameters.AddWithValue("@Marks", float.Parse(MarksTextBox.Text));
                command.Parameters.AddWithValue("@Attendance", float.Parse(AttendanceTextBox.Text));

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("Student added successfully!");
                this.Close();
            }
        }
    }
}
