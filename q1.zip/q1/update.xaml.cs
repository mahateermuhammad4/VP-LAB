﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Data.SqlClient;

namespace q1
{
    
    public partial class update : Window
    {
        private string connectionstring;
        public update(string connectionstring)
        {
            InitializeComponent();
            this.connectionstring = connectionstring;
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            if(string.IsNullOrEmpty(IdTextBox.Text ) || 
                string.IsNullOrWhiteSpace(NameTextBox.Text) ||
                string.IsNullOrWhiteSpace(MarksTextBox.Text) ||
                string.IsNullOrWhiteSpace(GradeTextBox.Text) ||
                string.IsNullOrWhiteSpace(SubjectTextBox.Text) ||
                string.IsNullOrWhiteSpace(AttendanceTextBox.Text)
                )
            {
                MessageBox.Show("Please fill all the required forms");
            }

            int attendance = int.Parse(AttendanceTextBox.Text);
            if (!int.TryParse(IdTextBox.Text, out int id) 
                || !int.TryParse(MarksTextBox.Text, out int marks) 
                //|| !int.TryParse(AttendanceTextBox.Text,out int attendance)
                )

            {
                MessageBox.Show("Please enter valid numeric values for id,marks and attendance.");
                return;
            }

            string name = NameTextBox.Text;
           
            string grade = GradeTextBox.Text;
            string subject = SubjectTextBox.Text;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionstring))
                {
                    con.Open();
                    string query = "UPDATE Students SET Name = @Name,Grade = @Grade,Subject = @Subject,Marks =@Marks,AttendancePercentage = @AttendancePercentage WHERE StudentID=@StudentID";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("Name", name);
                        cmd.Parameters.AddWithValue("Grade", grade);
                        cmd.Parameters.AddWithValue("Subject", subject);
                        cmd.Parameters.AddWithValue("Marks", marks);
                        cmd.Parameters.AddWithValue("AttendancePercentage", attendance);
                        cmd.Parameters.AddWithValue("StudentID", id);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Updated successfully");

                        cmd.Parameters.AddWithValue("Name", name);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
